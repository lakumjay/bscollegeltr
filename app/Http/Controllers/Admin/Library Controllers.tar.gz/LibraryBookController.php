<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\LibraryBook;
use App\Models\LibraryCategory;
use App\Models\LibraryAuthor;
use App\Models\LibraryPublisher;
use App\Models\LibraryRack;
use DB;
class LibraryBookController extends Controller
{

     public function __construct()
    {
        $this->middleware('auth');
       
    }
    public function edit($id)
    {
      $uid=Auth::user()->id;
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
  
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
  $LibraryBookEdit=LibraryBook::where('uid',$uid)->where('id',$id)->get();
  if(count($LibraryBookEdit)>0){
    foreach($LibraryBookEdit as $data){

  $LibraryCategory=LibraryCategory::where('uid',$uid)->get();
  $LibraryAuthor=LibraryAuthor::where('uid',$uid)->get();
  $LibraryPublisher=LibraryPublisher::where('uid',$uid)->get();
  $LibraryBook=LibraryBook::where('uid',$uid)->get();
    $LibraryRack=LibraryRack::where('uid',$uid)->get();

   return view('admin/library/book_edit',compact('LibraryBook','LibraryCategory','LibraryAuthor','LibraryPublisher','LibraryRack','data'));
    }}
    }






        public function editSave($id,Request $req)
    {
 		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
  $LibraryBookEdit=LibraryBook::where('uid',$uid)->where('id',$id)->get();
  if(count($LibraryBookEdit)>0){
   LibraryBook::where('uid',$uid)->where('id',$id)->update([
'AccessionNumber'=>$req->AccessionNumber,
'ClassificationNumber'=>$req->ClassificationNumber,
'BookTitle'=>$req->BookTitle,
'Langauge'=>$req->Langauge,
'ISBN_No'=>$req->ISBN_No,
'VolumeNo'=>$req->VolumeNo,
'Page'=>$req->Page,
'RowNumber'=>$req->RowNumber,
'Price'=>$req->Price,
'Status'=>$req->Status,
'library_categories_id'=>$req->library_categories_id,
'library_authors_id'=>$req->library_authors_id,
'library_publishers_id'=>$req->library_publishers_id,
'library_racks_id'=>$req->library_racks_id
]);
 return redirect("admin/library/book/edit/".$id)->with("success","Book created successfully!");

     }
    }
public function index()
{
  		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
  $LibraryBook=LibraryBook::where('uid',$uid)->with("LibraryCategory")->with("LibraryAuthor")->with("LibraryPublisher")->with("LibraryRack")  ->get();
 
   return view('admin/library/book',compact('LibraryBook'));
}
public function add()
{
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
  $LibraryCategory=LibraryCategory::where('uid',$uid)->get();
  $LibraryAuthor=LibraryAuthor::where('uid',$uid)->get();
  $LibraryPublisher=LibraryPublisher::where('uid',$uid)->get();
  $LibraryBook=LibraryBook::where('uid',$uid)->get();
    $LibraryRack=LibraryRack::where('uid',$uid)->get();

   return view('admin/library/book_add',compact('LibraryBook','LibraryCategory','LibraryAuthor','LibraryPublisher','LibraryRack'));
}
public function store(Request $req)
{
  		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
   $LibraryBook=new LibraryBook();
$LibraryBook->AccessionNumber=$req->AccessionNumber;
$LibraryBook->ClassificationNumber=$req->ClassificationNumber;
$LibraryBook->BookTitle=$req->BookTitle;
$LibraryBook->Langauge=$req->Langauge;
$LibraryBook->ISBN_No=$req->ISBN_No;
$LibraryBook->VolumeNo=$req->VolumeNo;
$LibraryBook->Page=$req->Page;
$LibraryBook->RowNumber=$req->RowNumber;
$LibraryBook->Price=$req->Price;
$LibraryBook->Status=$req->Status;
$LibraryBook->library_categories_id=$req->library_categories_id;
$LibraryBook->library_authors_id=$req->library_authors_id;
$LibraryBook->library_publishers_id=$req->library_publishers_id;
$LibraryBook->library_racks_id=$req->library_racks_id;
$LibraryBook->uid=$uid;
$LibraryBook->user_id=$user_id;
$LibraryBook->save();
return redirect("admin/library/book_add")->with("success","Book created successfully!");
}
	
public function issue_book (){
	
	return view('admin/library/issue_book');
	
}
	
}
