<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\LibraryPublisher;
use DB;
class LibraryPublisherController extends Controller
{

     public function __construct()
    {
        $this->middleware('auth');
       
    }
public function index()
{
  // $uid=Auth::user()->id;
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
	$LibraryPublisher=LibraryPublisher::where('uid',$uid)->get();
	 return view('admin/library/publisher',compact('LibraryPublisher'));
}
public function edit($id)
{
//   $uid=Auth::user()->id;
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
	$CategoryEdit=LibraryPublisher::where('uid',$uid)->where('id',$id)->get();
	if(count($CategoryEdit)>0){
		foreach($CategoryEdit as $data){
	$LibraryPublisher=LibraryPublisher::where('uid',$uid)->get();
$edit=true;
	 return view('admin/library/publisher',compact('edit','data','LibraryPublisher'));
	}

		}
		   return redirect("admin/library/publisher");

}
public function editStore($id,Request $req)
{
 //  $uid=Auth::user()->id;
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
	$CategoryEdit=LibraryPublisher::where('uid',$uid)->where('id',$id)->get();
	if(count($CategoryEdit)>0){
	 LibraryPublisher::where('uid',$uid)->where('id',$id)->update(['name'=>$req->name]);
   return redirect("admin/library/publisher")->with("success","Publisher updated successfully!");

		}
		   return redirect("admin/library/publisher");

}
   public function store(Request $req)
   {
 //  $uid=Auth::user()->id;
 		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
   $Category=new LibraryPublisher();
   $Category->name=$req->name;
    $Category->uid=$uid;
   $Category->save();
   return redirect("admin/library/publisher")->with("success","Category created successfully!");
   }
}
