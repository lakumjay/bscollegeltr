@extends('layouts.adminapp')

@section('title')
Library::Category Master
@endsection
@section('content')
<?php 
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 ?>
<div class="container">
    <div class="row justify-content-center">
    	@if(isset($edit))
 <div class="col-md-4">
            <div class="card">
                <div class="card-header">{{ __('Editing Category') }}


                </div>

                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif
<form method="post">
	@csrf
                      <div class="mb-3">
                              <label class="form-label">Name</label>
                              <input type="text" class="form-control" name="name" value="{{$data->name}}" placeholder="Enter Category name" required>
                            </div> 
                                
<button class="btn   btn-info">Update</button>
                        </form>
                </div>
            </div>
        </div>
    	@else
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">{{ __('Add Category') }}


                </div>

                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif
<form method="post">
	@csrf
                      <div class="mb-3">
                              <label class="form-label">Name</label>
                              <input type="text" class="form-control" name="name" placeholder="Enter Category name" required>
                            </div> 
                                
<button class="btn   btn-info">Add</button>
                        </form>
                </div>
            </div>
        </div>
        @endif
            <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Categories') }}


                </div>

                <div class="card-body">
                	@php
$sr=1;
@endphp
                  <div class="table-responsive">

                   <table class="table card-table table-vcenter text-nowrap datatable">
                   	                      <thead>

                   	<tr><th>Sr#</th><th>Name</th> <th>Action</th></tr>
                   </thead><tbody>
                   	@if(count($LibraryCategory)>0)
@foreach($LibraryCategory as $data)
<tr><td>{{$sr++}}</td><td>{{$data->name}}</td>   <td  >
                            
                            <a href="{{url('admin/library/categories/edit/'.$data->id)}}" class="btn btn-sm btn-info">Edit</a>

                          </td></tr>
@endforeach

                   	@endif
                   	</tbody>
                   </table>
               </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
