@extends('layouts.adminapp')

@section('title')
Library::Book Master
@endsection
@section('content')
<?php 
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
?>
<div class="container">
    <div class="row justify-content-center">
    
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Add Book') }}


                </div>

                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif

<form method="post">
	@csrf
  <div class="row">
                      <div class="col-sm-4 form-group">
                              <label class="form-label">Accession Number</label>
                              <input type="text" class="form-control" name="AccessionNumber" value="{{$data->AccessionNumber}}" placeholder="Enter Accession Number" required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Classification Number</label>
                              <input type="text" class="form-control" name="ClassificationNumber" value="{{$data->ClassificationNumber}}" placeholder="Enter Classification Number" required>
                            </div> 

                                 <div class="col-sm-4 form-group">
                              <label class="form-label">Category</label>
                              <select type="text" class="form-control" name="library_categories_id"    required>
@foreach($LibraryCategory as $LibraryCategory2)
<option value="{{$LibraryCategory2->id}}" <?php if($data->library_categories_id==$LibraryCategory2->id){ echo " selected "; } ?>>{{$LibraryCategory2->name}}</option>
@endforeach
                              </select>
                            </div> 
                        <div class="col-sm-4 form-group">
                              <label class="form-label">Book Title</label>
                              <input type="text" class="form-control" name="BookTitle" value="{{$data->BookTitle}}" placeholder="Enter Book Title" required>
                            </div> 

                             <div class="col-sm-4 form-group">
                              <label class="form-label">Book Langauge</label>
                              <input type="text" class="form-control" name="Langauge" value="{{$data->Langauge}}" placeholder="Enter Book Langauge" required>
                            </div>  
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Author</label>
                              <select type="text" class="form-control" name="library_authors_id"  required>
@foreach($LibraryAuthor as $LibraryAuthor2)
<option value="{{$LibraryAuthor2->id}}" <?php if($data->library_authors_id==$LibraryAuthor2->id){ echo " selected "; } ?> >{{$LibraryAuthor2->name}}</option>
@endforeach
                              </select>
                            </div>  
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Book Publisher</label>
                              <select type="text" class="form-control" name="library_publishers_id"   required>
@foreach($LibraryPublisher as $LibraryPublisher2)
<option value="{{$LibraryPublisher2->id}}" <?php if($data->library_publishers_id==$LibraryPublisher2->id){ echo " selected "; } ?> >{{$LibraryPublisher2->name}}</option>
@endforeach
                              </select>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">ISBN No</label>
                              <input type="text" class="form-control" name="ISBN_No" value="{{$data->ISBN_No}}" placeholder="Enter ISBN No." required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Volume No</label>
                              <input type="text" class="form-control" name="VolumeNo" value="{{$data->VolumeNo}}" placeholder="Enter Volume No." required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Pages</label>
                              <input type="text" class="form-control" name="Page" value="{{$data->Page}}" placeholder="Enter Pages" required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Rack</label>
                              <select type="text" class="form-control" name="library_racks_id"   placeholder="Enter Pages" required>
@foreach($LibraryRack as $LibraryRack2)
<option value="{{$LibraryRack2->id}}" <?php if($data->library_racks_id==$LibraryRack2->id){ echo " selected "; } ?> >{{$LibraryRack2->name}}</option>
@endforeach
                              </select>
                            </div>
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Row Number</label>
                              <input type="text" class="form-control" name="RowNumber" value="{{$data->RowNumber}}" placeholder="Enter Row Number" required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Price</label>
                              <input type="text" class="form-control" name="Price" value="{{$data->Price}}" placeholder="Enter Price" required>
                            </div> 
                            <div class="col-sm-4 form-group">
                              <label class="form-label">Status</label>
                              <select type="text" class="form-control" name="Status"   required>
                                <option value="active" <?php if($data->Status=="active"){ echo " selected "; } ?>>Active</option>
                                <option value="lost" <?php if($data->Status=="lost"){ echo " selected "; } ?>>Lost</option>
                                <option value="damage" <?php if($data->Status=="damage"){ echo " selected "; } ?>>Damage</option>
                              </select>
                            </div>         
                            </div>
                            <br>
<button class="btn   btn-info">Save</button>
                        </form>
                </div>
            </div>
        </div>
             
    </div>
</div>
@endsection
