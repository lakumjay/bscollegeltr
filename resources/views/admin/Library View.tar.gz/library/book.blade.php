@extends('layouts.adminapp')

@section('title')
Library::Author Master
@endsection
@section('content')
<?php 
		$mcq_test=0;	
$setting=1;
$students=1;
$fee=1;
$stock=1;
$bus_mgt=1;
$accounts=1;
$exam_management=1;
$student_gate_pass=1;
$library=1;
$empolyees=1;
$send_notification=1;
$mcq_test=1;
$reports=1;
$shoping=1;
$support=1;
   $uid=Auth::user()->id; 
 $type=Auth::user()->type;
 $editor=1;
if(Auth::user()->type=='school' || Auth::user()->type=='superadmin'){
  $uid=Auth::user()->id; 

}else{
  $uid=Auth::user()->uid; 	
}
 
// .................
$user_id=Auth::user()->other_user_id;
$get_session=DB::select("select session_id from users where id=$uid ");
if(count($get_session)>0){
foreach($get_session as $get_session2){
	$session_id=$get_session2->session_id;
}
}
$check_permission=DB::select("select * from user_permission where uid='$uid' and user_id='$user_id' "); 
if(count($check_permission)>0){
	foreach($check_permission as $check_permission2){
		$editor=$check_permission2->editor;
$students=$check_permission2->student; 
$fee=$check_permission2->fee; 
$stock=$check_permission2->stock; 
 
$accounts=$check_permission2->account;
$exam_management=$check_permission2->exam;
 
$library=$check_permission2->library;
$empolyees=0;
$send_notification=$check_permission2->notification;


	}
}else if(Auth::user()->type=='user'){
$uid=11111111111;

} 
 
?>
     <div class="row justify-content-center">
     
            <div class="col-md-11">
            <div class="card">
                <div class="card-header">{{ __('Books') }}
<div style="float: right;text-align: right;width: 100%">
<a href="book_add" class="btn btn-info"  >Add</a>
</div>
                </div>

                <div class="card-body">
                	@php
$sr=1;
@endphp
					<?php 
				 
					if(isset($_GET['del'])){
						$id=$_GET['del'];
					$del=DB::delete("delete from library_books where id='$id' and uid='$uid' ");
					if($del>0){
					?>
				 <script>
					 alert("Book is deleted successfuly");
					 window.location="";
					</script>
					<?php 
					}
					}
					 
					?>
                  <div class="table-responsive">

                   <table class="table card-table table-vcenter text-nowrap datatable" id="example">
                   	                      <thead>

                   	<tr><th>Sr#</th><th>Accession Number</th> <th>Classification Number</th><th>Category</th><th>Book Title
</th>
<th>Langauge</th><th>Author</th><th>Publisher</th><th>ISBN No
</th><th>Volume No
</th><th>Pages</th><th>Rack</th><th>Row Number
</th><th>Price</th><th>Status</th><th>Action</th>
</tr>
                   </thead><tbody>
                   @foreach($LibraryBook as $data)
<tr>
  <td>{{$sr++}}</td>
  <td>{{$data->AccessionNumber}}</td>
  <td>{{$data->ClassificationNumber}}</td>
  <td>{{$data->LibraryCategory->name}}</td>
  <td>{{$data->BookTitle}}</td>
  <td>{{$data->Langauge}}</td>
  <td>{{$data->LibraryAuthor->name}}</td>
  <td>{{$data->LibraryPublisher->name}}</td>
  <td>{{$data->ISBN_No}}</td>
  <td>{{$data->VolumeNo}}</td>
  <td>{{$data->Page}}</td>
  <td>{{$data->LibraryRack->name}}</td>
  <td>{{$data->RowNumber}}</td>
  <td>{{$data->Price}}</td>
  <td>{{$data->Status}}</td>
	
	
<td><a href="{{url('admin/library/book/edit/'.$data->id)}}" class="btn btn-info btn-sm">Edit</a>
	<a href="?del={{$data->id}}" class="btn btn-danger btn-sm">Delete</a>
	</td>
</tr>
                   @endforeach
                   	</tbody>
                   </table>
               </div>
                </div>
            </div>
        </div>
 </div>
@endsection
